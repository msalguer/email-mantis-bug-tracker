
Mantis_Email2Users
Versi�n 1.0

Copyrigth (c) 2015 Manuel Salguero
MIT License

--------------------
Conjunto de vistas y procedimientos en MySQL /
Set of views and procedures in MySQL

--------------------

DESCRIPCI�N PROYECTO:
Este c�digo sustituye la funci�n de env�o de correos del software opensource de gesti�n de incidencias Mantis Bug Tracker, 
para adaptarse mejor a entornos donde adem�s de trabajar el personal de desarrollo en la gesti�n de incidencias,
los usuarios crean y supervisan dichas incidencias.

La idea es que se pueda cambiar la incidencia de proyecto, y a�n as� al usuario que ha creado dicha incidencia, 
que la monitoriza, o que ha insertado alguna anotaci�n, le contin�en llegando correos sobre los cambios de estado.
Actualmente mantis no permite recibir correos ni visualizar la incidencia a usuarios que no est�n dados de alta
como usuarios del proyecto en cuesti�n, cuando se trata de un proyecto privado.

PARA QUE UN USUARIO NO RECIBA CORREOS:
Tambi�n se crea una tabla en donde se pueden insertar usuarios que est�n relacionados en un proyecto (ya
sea que haya creado la incidencia, haya realizado anotaciones o la monitorice), que no desee por alg�n
motivo continuar recibiendo incidencias de dicho proyecto.

PROGRAMACI�N DE COMPROBACI�N DE CAMBIOS EN INCIDENCIAS:
Se puede programar con el evento cada x minutos (a modificar). Habr�a que adaptar dichos minutos a las vistas siguientes:
- viewincidencias
- viewincidenciasnuevas

En dichas incidencias, el valor de UNIX_TIMESTAMP se encuentra en segundos, por lo que para una revisi�n cada 15 minutos
de cambios en incidencias, habr�a que colocar en el WHERE de dicho valor 15*60= 900

CONFIGURACI�N:
La opci�n de Administraci�n "Notificaciones por correo electr�nico" debe estar activada.

La opci�n personal de cada usuario, desde "Mi cuenta", "Preferencias", se debe desmarcar las opciones de recibir correos
para no recibir los correos est�ndar de Mantis junto con �stos.

Probado sobre MantisBT Versi�n 1.2.14

Ver licencia de Mantis Bug Tracker en: 
https://www.mantisbt.org/docs/master-1.2.x/en/developers.txt

------------------------

PROJECT DESCRIPTION:
This code replaces the function of email sending of Mantis Bug Tracker software,
to better suit besides working environments where staff development in the management of incidents,
users create and monitor incidents that are created by them.

The idea is that you can change the ticket project, yet the user who created this ticket,
the monitors, or you have inserted a note, we continue to arrive on post status changes.
Mantis not currently allowed to receive mail and viewed the incident to users who are not discharged
as users of the project in question, when it comes to a private project.

For a user NOT RECEIVE POST:
A table where you can add users who are related in a project is also created (and
is that created the incident, have made annotations or monitor), you do not want for some
why incidents continue receiving this project.

TESTING SCHEDULE CHANGES IN INCIDENTS:
It can be programmed with the event every x minutes (to change). We should adapt these minutes the following views:
- Viewincidencias
- Viewincidenciasnuevas

In these incidents, UNIX_TIMESTAMP value is in seconds, so for a review every 15 minutes
changes in incidence, should be placed in the WHERE of the value 15 * 60 = 900

CONFIGURATION:
Administration option "Email Notifications" must be activated.

The personal choice of each user, from "My account", "Settings", you should uncheck the options of receiving emails
not receive the standard post Mantis together with them.

MantisBT tested on version 1.2.14

See license Mantis Bug Tracker on:
https://www.mantisbt.org/docs/master-1.2.x/en/developers.txt

