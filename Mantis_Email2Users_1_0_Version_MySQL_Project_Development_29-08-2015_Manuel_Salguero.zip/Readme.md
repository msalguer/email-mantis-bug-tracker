Mantis_Email2Users
Este c�digo sustituye la funci�n de env�o de correos de software de gesti�n de incidencias opensource Mantis Bug Tracker.

This project substitute the function send emails Mantis Bug Tracker
